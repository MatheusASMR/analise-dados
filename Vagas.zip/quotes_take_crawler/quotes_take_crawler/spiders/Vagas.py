# -*- coding: utf-8 -*-
import scrapy


class VagasSpider(scrapy.Spider):
    name = 'vagas'
    start_urls = ['https://take1.recruitee.com/']

    def parse(self, response):
        for citacao in response.css("div.jobs-container"):
            yield {
                "title": citacao.css("h5.title::text").get(),
                "location": citacao.css("span.location::text").get(),
                "data": citacao.css("div.department::text").get(),
                "city": citacao.css("div.city::text").get(),
                "state": citacao.css("div.state::text").get(),
                "country": citacao.css("div.country::text").get(),
                "language": citacao.css("div.language::text").get(),

            }

